#!/usr/bin/env bash


###############################################################################
#                                                                             #
#                              HFRD-STARTER-TEST                              #
#                                                                             #
###############################################################################

# creaete required dirs
mkdir ./logs
mkdir ./tmp

# environment
source './hfrd_starter_test.cfg'
DATESTR=$(date +%Y-%m-%d" "%H:%M:%S" "%p)
PROG="[hfrd-starter-test]"
LOGFILE="$(pwd)/logs/hfrd_starter_test.log"
log() {
	printf "${PROG}  ${1}\n" | tee -a run.log
}
# STEP 0. API SERVER ENDPOINT DETAILS & SETUP #
log "$DATESTR"
log "0. Starting HFRD API STARTER TEST Script"

# STEP 1. REQUEST A STARTER PLAN NETWORK FROM IBP #
log "1. Sending Request To Provision A Starter Network"
# capture the request id in the response headers
requestid=$(curl --silent --include -X POST \
	"$apiserverbaseuri/service?env=$env" | awk -v FS="Request-Id: " 'NF>1 {print $2}')
requestid=${requestid%$'\r'}
if [ -z "$requestid" ]; then
	log "Error: Request ID invalid, exit 1."
	exit 1
fi
log "\t1.a) Server acknowledged with Request ID = $requestid"

# STEP 2. RETRIEVE STARTER PLAN INSTANCE SERVICE KEY #
log "2. Using Request ID = $requestid To Retrieve Service Credentials"
nextwaittime=0
while [ $nextwaittime -le 30 ]; do
	statuscode=$(curl --silent --output /dev/null --write-out %{http_code} \
		"$apiserverbaseuri/service?requestid=$requestid&env=$env")
	if [ "$statuscode" -eq 200 ]; then
		# key package is ready, retrieve it from the server
		curl --silent "$apiserverbaseuri/service?requestid=$requestid&env=$env" >| "./tmp/package.tar"
		# extract service id from the package
		serviceid=$(tar xfO "./tmp/package.tar" "workdir/results/service.json" | jq -r '.serviceid')
		serviceid=${serviceid%$'\r'}
		printf "\n"
		break
	elif [ "$statuscode" -eq 404 ] || [ "$statuscode" -eq 202 ]; then
		printf "."
		sleep $((nextwaittime++))
	else
		printf "\n"
		log "Error: Unable to retrieve service credentials, exit 2."
		exit 2
	fi
done
if [ -z "$serviceid" ]; then
	printf "\n"
	log "Error: Service Credentials invalid, exit 2."
	exit 2
fi
log "\t2.a) Retrieved service key package, Service ID = $serviceid"

# STEP 3. REQUEST CONNECTION PROFILE #
log "3. Using Service ID = $serviceid To Request Connection Profile"
CP_requestid=$(curl --silent --include \
	"$apiserverbaseuri/service/$serviceid/profile?env=$env" | awk -v FS="Request-Id: " 'NF>1{print $2}')
CP_requestid=${CP_requestid%$'\r'}
if [ -z "$CP_requestid" ]; then
	printf "\n"
	log "Error: Request ID invalid, exit 3."
	exit 3
fi
log "\t3.a) Server acknowledged with Request ID = $CP_requestid"

# STEP 4. RETRIEVE CONNECTION PROFILE #
log "4. Using Request ID = $CP_requestid and Service ID = $serviceid To Retrieve Connection Profile"
next_wait_time=0
while [ $next_wait_time -lt 30 ]; do
	statuscode=$(curl --silent --output /dev/null --write-out %{http_code} \
		"$apiserverbaseuri/service/$serviceid/profile?requestid=$CP_requestid&env=$env")
	if [ "$statuscode" -eq 200 ]; then
		# connection profile package is ready, retrieve from server and add to package.tar
		curl --silent "$apiserverbaseuri/service/$serviceid/profile?requestid=$CP_requestid&env=$env" >| "./tmp/package.tar"
		networkId=$(tar xfO "./tmp/package.tar" "workdir/results/org1.json" | jq -r '.["x-networkId"]')
		networkId=${networkId%$'\r'}
		printf "\n"
		break
	elif [ "$statuscode" -eq 404 ] || [ "$statuscode" -eq 202 ]; then
		printf "."
		sleep $((next_wait_time++))
	else
		printf "\n"
		log "Error: unable to retrieve connection profile, exit 4."
		exit 4
	fi
done
log "\t4.a)Connection Profile retrieved. Network ID = $networkId"


## This script is based out of Vance script
echo " ____    _____   _____           _____ _    ____       _____  ___ _________"
echo "|  _ \\  |_   _| | ____|         |  ___/ \  | __ )     |___ / ( _ )___ /___ \\"
echo "| |_) |   | |   |  _|    _____  | |_ / _ \ |  _ \ _____ |_ \ / _ \ |_ \ __) |"
echo "|  __/    | |   | |___  |_____| |  _/ ___ \| |_) |_____|__) | (_) |__) / __/"
echo "|_|       |_|   |_____|         |_|/_/   \_\____/     |____/ \___/____/_____|"

PROG="[PTE-FAB-3832]"

####################
# Helper Functions #
####################
get_pem() {
	awk '{printf "%s\\n", $0}' creds/org"$1"admin/msp/signcerts/cert.pem
}
echo
echo "############################################################"
echo $PWD
ls -ltr
echo "############################################################"

find / -name network.json

echo "############################################################"

## TODO: Refine this
if [ ! -d workdir/results ]; then
	echo "Credentials are not generated, cannot continue."
	exit 1
fi
mv ./workdir/results ./creds

#################
# Sanity Checks #
#################
if [[ ! -f creds/network.json ]]; then
	echo "Missing Network info, cannot continue."
	exit 1
elif [[ ! -f creds/org1.json ]]; then 
	echo "Missing org1 connection profile, cannot continue."
	exit1
elif [[ ! -f creds/org2.json ]]; then 
	echo "Missing org2 connection profile, cannot continue."
	exit1
fi


#################
# Environmental #
#################
API_ENDPOINT=$(jq -r .org1.url creds/network.json)
NETWORK_ID=$(jq -r .org1.network_id creds/network.json)
ORG1_API_KEY=$(jq -r .org1.key creds/network.json)
ORG2_API_KEY=$(jq -r .org2.key creds/network.json)
ORG1_API_SECRET=$(jq -r .org1.secret creds/network.json)
ORG2_API_SECRET=$(jq -r .org2.secret creds/network.json)
ORG1_ENROLL_SECRET=$(jq -r '.certificateAuthorities["org1-ca"].registrar[0].enrollSecret' creds/org1.json)
ORG2_ENROLL_SECRET=$(jq -r '.certificateAuthorities["org2-ca"].registrar[0].enrollSecret' creds/org2.json)
ORG1_CA_URL=$(jq -r '.certificateAuthorities["org1-ca"].url' creds/org1.json | cut -d '/' -f 3)
ORG2_CA_URL=$(jq -r '.certificateAuthorities["org2-ca"].url' creds/org2.json | cut -d '/' -f 3)


############################################################
# STEP 1 - generate user certs and upload to remote fabric #
############################################################
# save the cert
jq -r '.certificateAuthorities["org1-ca"].tlsCACerts.pem' creds/org1.json > cacert.pem
log "Enrolling admin user for org1."
export FABRIC_CA_CLIENT_HOME=${HOME}/creds/org1admin
fabric-ca-client enroll --tls.certfiles ${HOME}/cacert.pem -u https://admin:${ORG1_ENROLL_SECRET}@${ORG1_CA_URL}
# rename the keyfile
mv creds/org1admin/msp/keystore/* creds/org1admin/msp/keystore/priv.pem
# upload the cert
BODY1=$(cat <<EOF1
{
	"msp_id": "org1",
	"adminCertName": "PeerAdminCert1",
	"adminCertificate": "$(get_pem 1)",
	"peer_names": [
		"org1-peer1"
	],
	"SKIP_CACHE": true
}
EOF1
)
log "Uploading admin certificate for org 1."
curl -s -X POST \
	--header 'Content-Type: application/json' \
	--header 'Accept: application/json' \
	--basic --user ${ORG1_API_KEY}:${ORG1_API_SECRET} \
	--data "${BODY1}" \
    ${API_ENDPOINT}/api/v1/networks/${NETWORK_ID}/certificates

# STEP 1.2 - ORG2
log "Enrolling admin user for org2."
export FABRIC_CA_CLIENT_HOME=${HOME}/creds/org2admin
fabric-ca-client enroll --tls.certfiles ${HOME}/cacert.pem -u https://admin:${ORG2_ENROLL_SECRET}@${ORG2_CA_URL}
# rename the keyfile
mv creds/org2admin/msp/keystore/* creds/org2admin/msp/keystore/priv.pem
# upload the cert
BODY2=$(cat <<EOF2
{
 "msp_id": "org2",
 "adminCertName": "PeerAdminCert2",
 "adminCertificate": "$(get_pem 2)",
 "peer_names": [
   "org2-peer1"
 ],
 "SKIP_CACHE": true
}
EOF2
)
log "Uploading admin certificate for org 2."
curl -s -X POST \
	--header 'Content-Type: application/json' \
	--header 'Accept: application/json' \
	--basic --user ${ORG2_API_KEY}:${ORG2_API_SECRET} \
	--data "${BODY2}" \
    ${API_ENDPOINT}/api/v1/networks/${NETWORK_ID}/certificates


##########################
# STEP 2 - restart peers #
##########################
# STEP 2.1 - ORG1
PEER="org1-peer1"
log "Stoping ${PEER}"
curl -s -X POST \
	--header 'Content-Type: application/json' \
	--header 'Accept: application/json' \
	--basic --user ${ORG1_API_KEY}:${ORG1_API_SECRET} \
	--data-binary '{}' \
	${API_ENDPOINT}/api/v1/networks/${NETWORK_ID}/nodes/${PEER}/stop

log "Waiting for ${PEER} to stop..."
RESULT=""
while [[ ${RESULT} != "exited" ]]; do
	RESULT=$(curl -s -X GET \
		--header 'Content-Type: application/json' \
		--header 'Accept: application/json' \
		--basic --user ${ORG1_API_KEY}:${ORG1_API_SECRET} \
		${API_ENDPOINT}/api/v1/networks/${NETWORK_ID}/nodes/status | jq -r '.["'${PEER}'"].status')
done
log "${RESULT}"

log "Starting ${PEER}"
curl -s -X POST \
	--header 'Content-Type: application/json' \
	--header 'Accept: application/json' \
	--basic --user ${ORG1_API_KEY}:${ORG1_API_SECRET} \
	--data-binary '{}' \
	${API_ENDPOINT}/api/v1/networks/${NETWORK_ID}/nodes/${PEER}/start

log "Waiting for ${PEER} to start..."
RESULT=""
while [[ ${RESULT} != "running" ]]; do
	RESULT=$(curl -s -X GET \
		--header 'Content-Type: application/json' \
		--header 'Accept: application/json' \
		--basic --user ${ORG1_API_KEY}:${ORG1_API_SECRET} \
		${API_ENDPOINT}/api/v1/networks/${NETWORK_ID}/nodes/status | jq -r '.["'${PEER}'"].status')
done
log "${RESULT}"

# STEP 2.2 - ORG2
PEER="org2-peer1"
log "Stoping ${PEER}"
curl -s -X POST \
	--header 'Content-Type: application/json' \
	--header 'Accept: application/json' \
	--basic --user ${ORG2_API_KEY}:${ORG2_API_SECRET} \
	--data-binary '{}' \
	${API_ENDPOINT}/api/v1/networks/${NETWORK_ID}/nodes/${PEER}/stop

log "Waiting for ${PEER} to stop..."
RESULT=""
while [[ $RESULT != "exited" ]]; do
	RESULT=$(curl -s -X GET \
		--header 'Content-Type: application/json' \
		--header 'Accept: application/json' \
		--basic --user ${ORG2_API_KEY}:${ORG2_API_SECRET} \
		${API_ENDPOINT}/api/v1/networks/${NETWORK_ID}/nodes/status | jq -r '.["'${PEER}'"].status')
done
log "${RESULT}"

log "Starting ${PEER}"
curl -s -X POST \
	--header 'Content-Type: application/json' \
	--header 'Accept: application/json' \
	--basic --user ${ORG2_API_KEY}:${ORG2_API_SECRET} \
	--data-binary '{}' \
	${API_ENDPOINT}/api/v1/networks/${NETWORK_ID}/nodes/${PEER}/start

log "Waiting for ${PEER} to start..."
RESULT=""
while [[ $RESULT != "running" ]]; do
	RESULT=$(curl -s -X GET \
		--header 'Content-Type: application/json' \
		--header 'Accept: application/json' \
		--basic --user ${ORG2_API_KEY}:${ORG2_API_SECRET} \
		${API_ENDPOINT}/api/v1/networks/${NETWORK_ID}/nodes/status | jq -r '.["'${PEER}'"].status')
done
log "${RESULT}"


#########################
# STEP 3 - SYNC CHANNEL #
#########################
log "Syncing the channel."
curl -s -X POST \
	--header 'Content-Type: application/json' \
  	--header 'Accept: application/json' \
  	--basic --user ${ORG1_API_KEY}:${ORG1_API_SECRET} \
  	--data-binary '{}' \
  	${API_ENDPOINT}/api/v1/networks/${NETWORK_ID}/channels/defaultchannel/sync


# #####################################################
# # STEP 4 - generate the SCFile and place userInputs #
# #####################################################
# ##TODO: Make pte conversion public
# for (( i=1;i<=2;i++ ))
# do
# 	cp creds/org${i}.json node_sdk_tests/Connection_Profile_org${i}.json
# done
# ## Generate/copy the pte config files 
# cd node_sdk_tests
# node app generateptefile -p config-chan1-TLS.json

#####################################################
# STEP 4 - generate the SCFile and place userInputs #
#####################################################
log "Generating PTE SCFile and userInputs."
python ${HOME}/scripts/2o2pp-1ch-create_SCFile.py

# Sanity check to see if the PTE config file is geerated
if [[ ! -f ${HOME}/scripts/config-chan1-TLS.json ]]; then
	echo "Failed to generate config-chan1-TLS.json, cannot continue."
	exit 1
fi
cp ${HOME}/scripts/config-chan1-TLS.json ${PTE_PATH}/CITest/CISCFiles/config-chan1-TLS.json
cp ${HOME}/scripts/config-chan1-TLS.json ${PTE_PATH}/CITest/CISCFiles/config-chan2-TLS.json

### Switch to PTE Dir & replace channel names and modify configurations
cd ${PTE_PATH}
sed -i 's/testorgschannel1/defaultchannel/g' ./CITest/FAB-3832-4i/preconfig/samplecc/*.json
sed -i 's/testorgschannel2/defaultchannel/g' ./CITest/FAB-3832-4i/preconfig/samplecc/*.json
sed -i 's/testorgschannel1/defaultchannel/g' ./CITest/FAB-3832-4i/samplecc/*.json
sed -i 's/testorgschannel2/defaultchannel/g' ./CITest/FAB-3832-4i/samplecc/*.json
# sed -i 's/10000/20000/g' ./CITest/FAB-3832-4i/samplecc/*.json
		
##################################
# STEP 5 - PTE install chaincode #
##################################
log "---------------------------------"
log "---------------------------------"
log "Installing PTE Chaincode."
log "---------------------------------"
log "---------------------------------"
./pte_driver.sh CITest/FAB-3832-4i/preconfig/samplecc/runCases-samplecc-install-TLS.txt | tee -a run.log
 echo "$? --- Install Done"
sleep 5

######################################
# STEP 6 - PTE instantiate chaincode #
######################################
log "---------------------------------"
log "---------------------------------"
log "Instantiating PTE Chaincode."
log "---------------------------------"
log "---------------------------------"
./pte_driver.sh CITest/FAB-3832-4i/preconfig/samplecc/runCases-samplecc-instantiate-TLS.txt | tee -a run.log
echo "$? --- Instantiation Done"
sleep 30


####################
# STEP 7 - PTE run #
####################
log "---------------------------------"
log "---------------------------------"
log "Running PTE Now!"
log "---------------------------------"
log "---------------------------------"
./pte_mgr.sh CITest/FAB-3832-4i/samplecc/PTEMgr-FAB-3832-4i-TLS.txt | tee -a run.log
echo "$? --- Sending Transactions"

##TODO: Is this redundant ?
mkdir -p ${HOME}/results
cp run.log ${HOME}/results