#!/bin/bash

printf "\n============= Install NVM ============= \n"
##Install NVM
wget https://raw.githubusercontent.com/hyperledger/fabric/master/devenv/install_nvm.sh
chmod +x install_nvm.sh
./install_nvm.sh
nvm install v8.9.4


if [ ! -d fabric-#test ]; then
printf "\n============= Clone PTE ============= \n"
git clone https://github.com/hyperledger/fabric-test
cd fabric-test/tools/PTE
npm install ## Do we need to install nvm ?
git clone git@github.ibm.com:IBM-Blockchain/quality.git
cd quality/node_sdk_tests
npm install

fi


function generateAndUploadCerts(){
        #Get the connection proiles from HFRD APIs and copy and rename them in quality folder
	#node app getconnectionprofile -a "_jDmhQJ7RTBc1Dqze3iGmc2bHjkpZ1zCM4AnK3eEdH4J" -s "Blockchain-may14" -x dev -o rasara -e https://api.ng.bluemix.net
	## Set PWD as GOPATH
	export VERSION=1.1.0
	export ARCH=$(echo "$(uname -s|tr '[:upper:]' '[:lower:]'|sed 's/mingw64_nt.*/windows/')-$(uname -m | sed 's/x86_64/amd64/g')" | awk '{print tolower($0)}')
	curl https://nexus.hyperledger.org/content/repositories/releases/org/hyperledger/fabric-ca/hyperledger-fabric-ca/${ARCH}-${VERSION}/hyperledger-fabric-ca-${ARCH}-${VERSION}.tar.gz | tar xz

	#upload Admin cert on Org1 & Org2
	for (( i=1;i<=2;i++ ))
	do
		cp ../../workdir/results/org${i}.json Connection_Profile_org${i}.json ## TODO : Is this the right place
		node app upload_cert -n Org${i}AdminCert -o ${i}
	done
	export NETWORK_ID=$(jq -r .'["x-networkId"]' ../../workdir/results/org1.json)
}

function SyncChannel(){
	node app sync_channel -c defaultchannel -o 1
}

function generatePteFile(){
	node app generateptefile -p $1
        cp ${1} ../../CITest/CISCFiles/config-chan1-TLS.json
        cp ${1} ../../CITest/CISCFiles/config-chan2-TLS.json
        cd ../../
}

function runPTEtest() {
        #cp NETWORK_ID.json ../../CITest/CISCFiles/config-chan1-TLS.json
        #cp NETWORK_ID.json ../../CITest/CISCFiles/config-chan2-TLS.json
        #cd ../../

	#cd fabric-test/tools/PTE
        #3832 & 3834
        sed -i 's/testorgschannel1/defaultchannel/g' ./CITest/FAB-3832-4i/preconfig/samplecc/*.json
        sed -i 's/testorgschannel2/defaultchannel/g' ./CITest/FAB-3832-4i/preconfig/samplecc/*.json
        sed -i 's/testorgschannel1/defaultchannel/g' ./CITest/FAB-3832-4i/samplecc/*.json
        sed -i 's/testorgschannel2/defaultchannel/g' ./CITest/FAB-3832-4i/samplecc/*.json
	sed -i 's/10000/500/g' ./CITest/FAB-3832-4i/samplecc/*.json

	export GOPATH=$PWD
        mkdir -p $GOPATH/src/github.com/hyperledger/fabric-test/chaincodes/samplecc/go
        cp ../../chaincodes/samplecc/go/chaincode_sample.go $GOPATH/src/github.com/hyperledger/fabric-test/chaincodes/samplecc/go/
	cp ../../
	./pte_driver.sh CITest/FAB-3832-4i/preconfig/samplecc/runCases-samplecc-install-TLS.txt
	echo "$? --- Install Done"
	./pte_driver.sh CITest/FAB-3832-4i/preconfig/samplecc/runCases-samplecc-instantiate-TLS.txt
	echo "$? --- Instantiation Done"
	./pte_mgr.sh CITest/FAB-3832-4i/samplecc/PTEMgr-FAB-3832-4i-TLS.txt
	echo "$? --- Sending Transactions"
	printf "\n\n =============== Done Testing =============== \n\n"
}

## Generate the admin certs of each org and upload the certs
generateAndUploadCerts
## sync the channel with the admin certs
SyncChannel
#Generate PTE config file
generatePteFile ${NETWORK_ID}.json

runPTEtest
