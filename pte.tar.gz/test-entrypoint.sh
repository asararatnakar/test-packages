#!/usr/bin/env bash

TOP=$(pwd)

cp Dockerfile.in Dockerfile
sed -i 's/FABRIC_VERSION/1.1.0/g' Dockerfile

docker build -t pte-fab-3832 .

docker run pte-fab-3832 ./docker-entrypoint.sh
