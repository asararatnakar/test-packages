#!/usr/bin/env bash

TOP=$(pwd)

docker build -t pte-hfrd .

docker run pte-hfrd ./docker-entrypoint.sh
