#!/usr/bin/env bash
###############################################################################
#                                                                             #
#                              HFRD-STARTER-TEST                              #
#                                                                             #
###############################################################################

# environment
source './hfrd_starter_test.cfg'
DATESTR=$(date +%Y-%m-%d" "%H:%M:%S" "%p)
PROG="[hfrd-starter-test]"
LOGFILE="$(pwd)/logs/hfrd_starter_test.log"

# Helper functions
function log() {
	printf "$PROG\t$1\n" | tee -a $LOGFILE
}

# STEP 0. API SERVER ENDPOINT DETAILS & SETUP #
log "$DATESTR"
log "0. Starting HFRD API STARTER TEST Script"

# STEP 1. UPLOAD PTE TEST PACKAGE TO HTTP SERVER #
log "1. Upload PTE Test Package"
printf "Upload /tmp/pte.tar.gz to an HTTP server so that the test runner can retrieve it.\n"
PTE_URL=##Get the URL

# STEP 2. START THE PTE TEST RUN
log "2. Starting PTE Test Run"
## TODO: retrieve test_requestid from the following request
statuscode=$(curl -X POST --silent "$apiserverbaseuri/test" \
	-d '{"url":"'$PTE_URL'","hash":"'$MD5SUM'","startcmd":"test-entrypoint.sh"}')
log "\t2.a) Point your browser to $apiserverbaseuri/test?requestid=$test_reqeustid to observe your run."
sleep 5

exit 0
