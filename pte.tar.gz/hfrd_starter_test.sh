#!/usr/bin/env bash
###############################################################################
#                                                                             #
#                              HFRD-STARTER-TEST                              #
#                                                                             #
###############################################################################

# cleanup previous runs
rm -rf logs
mkdir ./logs
# environment
source ./hfrd_starter_test.cfg
DATESTR=$(date +%Y-%m-%d" "%H:%M:%S" "%p)
PROG="[hfrd-starter-test]"
LOGFILE="$(pwd)/logs/hfrd_starter_test.log"

# Helper functions
function log() {
	printf "$PROG\t$1\n" | tee -a $LOGFILE
}

# STEP 0. API SERVER ENDPOINT DETAILS & SETUP #
log "$DATESTR"
log "0. Starting HFRD API STARTER TEST Script"

# STEP 1. UPLOAD PTE TEST PACKAGE TO HTTP SERVER #
log "1. Upload PTE Test Package"
printf "Upload /tmp/pte.tar.gz to an HTTP server so that the test runner can retrieve it.\n"
##TODO: Host the test package in some other repo ?
PTE_URL=https://github.com/asararatnakar/test-packages/raw/master/pte.tar.gz
# PTE_URL=https://192.30.253.113/asararatnakar/test-packages/raw/master/pte.tar.gz
MD5SUM=8843639f595ecdf7f70cf10b0990e38e
# STEP 2. START THE PTE TEST RUN
log "2. Starting PTE Test Run"
printf "\n\n\n $apiserverbaseuri \n\n"
echo curl -X POST --silent "$apiserverbaseuri/test" -d '{"url":"'$PTE_URL'","hash":"'$MD5SUM'","startcmd":"test-entrypoint.sh","sslcerts":"Yes"}'
# exit
## TODO: retrieve test_requestid from the following request
statuscode=$(curl -X POST --silent "$apiserverbaseuri/test" \
	-d '{"url":"'$PTE_URL'","hash":"'$MD5SUM'","startcmd":"test-entrypoint.sh","sslcerts":"ignore"}')

log "\tResponse: $statuscode"

log "\t2.a) Point your browser to $apiserverbaseuri/test?requestid=$test_reqeustid to observe your run."
sleep 5

exit 0